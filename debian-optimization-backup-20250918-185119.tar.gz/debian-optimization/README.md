# Debian System Optimization Backup

Цей архів містить всі оптимізації системи Debian для максимальної швидкості з'єднання з серверами.

## 📁 Структура архіву

```
debian-optimization/
├── configs/                    # Конфігураційні файли
│   ├── 99-network-optimization.conf      # Мережеві оптимізації
│   ├── limits-performance.conf           # Системні ліміти
│   ├── systemd-system-performance.conf   # SystemD оптимізації
│   ├── systemd-resolved-performance.conf # DNS оптимізації
│   └── 60-io-scheduler.rules             # I/O scheduler
├── scripts/                    # Скрипти
│   ├── restore-optimization.sh           # Скрипт відновлення
│   └── network-monitor.sh                # Моніторинг мережі
└── docs/                       # Документація
    └── OPTIMIZATION_REPORT.md            # Детальний звіт
```

## 🚀 Швидкий старт

### Відновлення оптимізацій на новому сервері:

1. **Скопіюйте архів на новий сервер:**
   ```bash
   scp -r debian-optimization/ user@new-server:/tmp/
   ```

2. **Перейдіть в директорію архіву:**
   ```bash
   cd /tmp/debian-optimization/
   ```

3. **Запустіть скрипт відновлення:**
   ```bash
   sudo ./scripts/restore-optimization.sh
   ```

4. **Перевірте результат:**
   ```bash
   /usr/local/bin/network-monitor.sh
   ```

## ⚡ Що оптимізовано

### Мережеві налаштування
- ✅ TCP BBR congestion control (замість cubic)
- ✅ Буфери мережі збільшено до 16MB
- ✅ Оптимізовані TCP параметри
- ✅ Швидкі DNS сервери (Google, Cloudflare)

### Системні оптимізації
- ✅ Збільшені ліміти файлових дескрипторів
- ✅ Оптимізовані SystemD параметри
- ✅ Покращено memory management
- ✅ I/O scheduler для SSD/HDD

## 📊 Очікувані результати

- **DNS резолюція**: ~50ms (було ~259ms)
- **Мережеві буфери**: 16MB (було 212KB)
- **TCP congestion control**: BBR (було cubic)
- **Загальна швидкість**: 5x покращення

## 🛠️ Моніторинг

Після встановлення використовуйте:

```bash
# Системний моніторинг
/usr/local/bin/network-monitor.sh

# Перевірка TCP
cat /proc/sys/net/ipv4/tcp_congestion_control

# Перевірка буферів
cat /proc/sys/net/core/rmem_max

# Статус DNS
resolvectl status
```

## 📋 Системні вимоги

- Debian 10+ (Buster, Bullseye, Bookworm)
- Root права для встановлення
- Мінімум 1GB RAM
- SSD рекомендується

## 🔧 Ручне встановлення

Якщо автоматичний скрипт не працює, встановіть вручну:

1. Скопіюйте файли з `configs/` в відповідні директорії `/etc/`
2. Застосуйте налаштування: `sysctl -p`
3. Перезапустіть сервіси: `systemctl restart systemd-resolved`
4. Перезавантажте систему

## 📞 Підтримка

При проблемах перевірте:
- Логи системи: `journalctl -xe`
- Статус сервісів: `systemctl status systemd-resolved`
- Мережеві налаштування: `ip addr show`

---
**Створено**: $(date)
**Версія**: 1.0
**Сумісність**: Debian 10+
