#!/bin/bash

# Скрипт для відновлення оптимізацій Debian
# Використання: sudo ./restore-optimization.sh

set -e

echo "🚀 Відновлення оптимізацій Debian..."

# Перевірка прав root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Потрібні права root. Запустіть: sudo $0"
    exit 1
fi

# Створення директорій
echo "📁 Створення директорій..."
mkdir -p /etc/sysctl.d
mkdir -p /etc/security/limits.d
mkdir -p /etc/systemd/system.conf.d
mkdir -p /etc/systemd/resolved.conf.d
mkdir -p /etc/udev/rules.d
mkdir -p /usr/local/bin

# Копіювання конфігурацій
echo "📋 Копіювання конфігурацій..."

# Мережеві оптимізації
if [ -f "configs/99-network-optimization.conf" ]; then
    cp configs/99-network-optimization.conf /etc/sysctl.d/
    echo "✅ Мережеві оптимізації скопійовано"
fi

# Системні ліміти
if [ -f "configs/limits-performance.conf" ]; then
    cp configs/limits-performance.conf /etc/security/limits.d/99-performance.conf
    echo "✅ Системні ліміти скопійовано"
fi

# SystemD оптимізації
if [ -f "configs/systemd-system-performance.conf" ]; then
    cp configs/systemd-system-performance.conf /etc/systemd/system.conf.d/99-performance.conf
    echo "✅ SystemD оптимізації скопійовано"
fi

# DNS оптимізації
if [ -f "configs/systemd-resolved-performance.conf" ]; then
    cp configs/systemd-resolved-performance.conf /etc/systemd/resolved.conf.d/99-performance.conf
    echo "✅ DNS оптимізації скопійовано"
fi

# I/O scheduler
if [ -f "configs/60-io-scheduler.rules" ]; then
    cp configs/60-io-scheduler.rules /etc/udev/rules.d/
    echo "✅ I/O scheduler скопійовано"
fi

# Скрипт моніторингу
if [ -f "scripts/network-monitor.sh" ]; then
    cp scripts/network-monitor.sh /usr/local/bin/
    chmod +x /usr/local/bin/network-monitor.sh
    echo "✅ Скрипт моніторингу скопійовано"
fi

# Застосування налаштувань
echo "⚙️ Застосування налаштувань..."

# Завантаження sysctl
sysctl -p /etc/sysctl.d/99-network-optimization.conf

# Перезапуск systemd-resolved
systemctl restart systemd-resolved

# Перезавантаження udev
udevadm control --reload-rules

echo "✅ Всі налаштування застосовано!"

# Тестування
echo "🧪 Тестування оптимізацій..."

# Перевірка TCP congestion control
TCP_CC=$(cat /proc/sys/net/ipv4/tcp_congestion_control)
echo "TCP Congestion Control: $TCP_CC"

# Перевірка буферів
RMEM_MAX=$(cat /proc/sys/net/core/rmem_max)
WMEM_MAX=$(cat /proc/sys/net/core/wmem_max)
echo "Network Buffers: RMEM=$RMEM_MAX, WMEM=$WMEM_MAX"

# Перевірка DNS
echo "DNS Status:"
resolvectl status | head -5

echo ""
echo "🎉 Оптимізації успішно відновлено!"
echo "📊 Для моніторингу використовуйте: /usr/local/bin/network-monitor.sh"
echo "📋 Документація: docs/OPTIMIZATION_REPORT.md"
