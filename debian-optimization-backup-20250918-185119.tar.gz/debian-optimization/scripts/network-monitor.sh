#!/bin/bash
# Network performance monitoring script

echo "=== Network Performance Monitor ==="
echo "Date: $(date)"
echo

echo "=== TCP Congestion Control ==="
cat /proc/sys/net/ipv4/tcp_congestion_control
echo

echo "=== Network Buffer Sizes ==="
echo "rmem_max: $(cat /proc/sys/net/core/rmem_max)"
echo "wmem_max: $(cat /proc/sys/net/core/wmem_max)"
echo "rmem_default: $(cat /proc/sys/net/core/rmem_default)"
echo "wmem_default: $(cat /proc/sys/net/core/wmem_default)"
echo

echo "=== Active Connections ==="
ss -s
echo

echo "=== DNS Resolution Test ==="
time nslookup google.com > /dev/null 2>&1 && echo "DNS: OK" || echo "DNS: FAILED"
echo

echo "=== Network Latency Test ==="
ping -c 3 8.8.8.8 | tail -1
echo

echo "=== System Load ==="
uptime
echo

echo "=== Memory Usage ==="
free -h
echo

echo "=== File Descriptors ==="
echo "Open files: $(lsof | wc -l)"
echo "Max files: $(cat /proc/sys/fs/file-max)"
echo
